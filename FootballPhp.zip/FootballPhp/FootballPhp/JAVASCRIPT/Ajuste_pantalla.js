/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

                    if(screen.width > 1024)
                    {
                    //Para las resoluciones mayores a 1024
                    document.write('<link rel="stylesheet"  type="text/css" href="mayor1024.css" /> ');
                    }
                    else if( screen.wisth == 1024)
                    {
                    document.write('<link rel="stylesheet"  type="text/css" href="menor1024.css" /> ');
                    }
                    else if(screen.wisth < 1024)
                    {
                    document.write('<link rel="stylesheet"  type="text/css" href="menor1024.css" /> ');
                    }
                    
                  

