﻿(function ($) {
    $(document).ready(function () {
        $('#cssmenu').prepend('<div id="bg-one"></div><div id="bg-two"></div><div id="bg-three"></div><div id="bg-four"></div>');
    });
})(jQuery);