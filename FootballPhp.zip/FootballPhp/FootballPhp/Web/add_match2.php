<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" 
      type="image/png" 
      href="../images/logito.jpg">
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>Admin</title>
    <!-- Bootstrap Core CSS -->
    <link href="../Estilos/bootstrap.min.css" rel="stylesheet" type="text/css" />

    <!-- Custom CSS -->
    <link href="../Estilos/sb-admin.css" rel="stylesheet" type="text/css" />

    <!-- Custom Fonts -->
    <link href="../Estilos/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!--Estilos de la parte negra grafica-->
    <link rel="stylesheet" type="text/css" href="../Estilos/normalize_administrador.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/demo_administrador.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/cs-select_administrador.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/cs-skin-elastic_administrador.css" />
    <!--fin de la parte negra grafica-->
    <!--Parte grafica de ingresar texto-->
    <link rel="stylesheet" type="text/css" href="../Estilos/normalize_add_admin.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/font-awesome.min_add_admin.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/demo_add_admin.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/set2_add_admin.css" />
    <!--Fin de parte grafica texto-->

    <!--imagen spam color verde y centrado de la pagina-->
    <link rel="stylesheet" type="text/css" href="../Estilos/match/normalize.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/match/demo.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/match/style1.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/match2/style1.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/match2/demo.css" />
    <script src="../JAVASCRIPT/matchphp/modernizr.custom.js"></script>
    <!--FIN de color spam y centrado de la pag-->
    <!--Estos son los CSS de los check box-->
    <link rel="stylesheet" type="text/css" href="../Estilos/demo_administrador_checkbox.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/component_administrador.css" />
    <!--estos son los efectos del checkbox-->
    <link rel="stylesheet" type="text/css" href="../Estilos/checkbox.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/checkbox2.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/checkbox3.css" />
    <!--Fin de CSS los Checkbox-->
    <style type="text/css">
        /* para poder cerrar las ventanas de spam  */
        .overlay .overlay-close {
            width: 80px;
            height: 80px;
            position: absolute;
            right: 100px;
            top: 80px;
            overflow: hidden;
            border: none;
            background: url(../images/cross.png) no-repeat center center;
            text-indent: 200%;
            color: transparent;
            outline: none;
            z-index: 100;
        }
      </style>
      <style type="text/css">
        .overlay1 .overlay-close1 {
            width: 80px;
            height: 80px;
            position: absolute;
            right: 100px;
            top: 80px;
            overflow: hidden;
            border: none;
            background: url(../images/cross.png) no-repeat center center;
            text-indent: 200%;
            color: transparent;
            outline: none;
            z-index: 100;
        }
        /*Fin de cerrar las ventanas de spam*/
    </style>
    <style type="text/css">
        body {
            background-image: url("../images/stadium.jpg");
            background-attachment: fixed;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Admin</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-user"></i>
                        OPTIONS
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="../Web/add_administador.php">
                                <i class="fa fa-fw fa-user"></i>
                                New Admin
                            </a>
                        </li>
                        <li>
                            <a href="../index.php">
                                <i class="fa fa-fw fa-power-off"></i>
                                Log Out
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="../Web/administrador.php">
                            <i class="fa fa-fw fa-desktop">NEW CHAMPIONSHIP</i>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo">
                            <i class="fa fa-fw fa-arrows-v"></i>
                            REGISTER
                            <i class="fa fa-fw fa-caret-down"></i>
                        </a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="../Web/add_admin.php">ADD SPORTING EVENT</a>
                            </li>
                            <li>
                                <a href="../Web/stadium.php">ADD STADIUM</a>
                            </li>
                            <li>
                                <a href="../web/add_admin_equipo.php">ADD TEAM</a>
                            </li>
                            <li>
                                <a href="../Web/add_players.php">ADD PLAYERS</a>
                            </li>
                            <li>
                                <a href="../Web/add_match.php">MATCH</a>
                            </li>
                            <li>
                                <a href="../Web/Update_player.php">UPDATES PLAYER</a>
                            </li>
                            <li>
                                <a href="../Web/Update_team.php">UPDATES TEAM</a>
                            </li>
                            <li>
                                <a href="../Web/Update_stadium.php">UPDATES STADIUM</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <form action="logicphp/add_match2.php" method="post" class="ac-custom ac-checkbox ac-cross">
            <div class="container-fluid">
                <div class="container">

                    <div class="equipoA">
                        <!-- Top Navigation -->
                        <div class="codrops-top clearfix"></div>
                        <section>
                            <p>
                                <button id="trigger-overlay" type="button">TEAM A</button>
                            </p>
                        </section>
                        <!-- /container -->
                        <!-- open/close -->
                        <div class="overlay overlay-hugeinc">
                            <button type="button" class="overlay-close">Close</button>
                            <nav>
                                <ul>
                                    <li>
                                        <h1 class="letras1">SELECT TEAM</h1>
                                        <div class="parte1">                                            
                                            <select name="team1" class="cs-select cs-skin-elastic">
                                                <option value="" >FOOTBALL TEAM</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>EVENT</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li>
                                        <h1 class="letras2">TIME</h1>
                                        <div class="parte2">                                            
                                            <select name="team1" class="cs-select cs-skin-elastic">
                                                <option value="" >TIME</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>$i</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li>
                                        <h1 class="letras3">PLAYER</h1>
                                        <div class="parte3">                                            
                                            <select name="player1" class="cs-select cs-skin-elastic">
                                                <option value="" >PLAYER</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>$i</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li>
                                        <h1 class="letras4">ACTION</h1>
                                        <div class="parte4">                                            
                                            <select name="action1" class="cs-select cs-skin-elastic">
                                                <option value="">ACTION</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>$i</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="equipoB">
                        <!-- Top Navigation -->
                        <div class="codrops-top1 clearfix1"></div>

                        <section>
                            <p>
                                <button id="trigger-overlay1" type="button">TEAM B</button>
                            </p>
                        </section>
                        <!-- /container -->
                        <!-- open/close -->
                        <div class="overlay1 overlay-hugeinc1">
                            <button type="button" class="overlay-close1">Close</button>
                            <nav class="">
                               <ul>
                                    <li>
                                        <h1 class="letras1">SELECT TEAM</h1>
                                        <div class="parte1">                                            
                                            <select name="team2" class="cs-select cs-skin-elastic">
                                                <option value="" >FOOTBALL TEAM</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>EVENT</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li>
                                        <h1 class="letras2">TIME</h1>
                                        <div class="parte2">                                            
                                            <select name="time2" class="cs-select cs-skin-elastic">
                                                <option value="" >TIME</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>$i</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li>
                                        <h1 class="letras3">PLAYER</h1>
                                        <div class="parte3">                                            
                                            <select name="player2" class="cs-select cs-skin-elastic">
                                                <option value="" >PLAYER</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>$i</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                                    <li>
                                        <h1 class="letras4">ACTION</h1>
                                        <div class="parte4">                                            
                                            <select name="action2" class="cs-select cs-skin-elastic">
                                                <option value="">ACTION</option>
                                                <?php
                                                $i=0;
                                                while($i<10){
                                                    echo "<option value='france' data-class='a$i'>$i</option>";
                                                    $i++;
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </li>
                               </ul>     
                            </nav>
                        </div>
                    </div>
                   <div class="wrapper2">
                        <section>
					        <h1 class="letra">SAVE</h1>
					        <input type="submit" value="SAVE" class="push_button">     
                        </section>
                    </div>    
                </div>
            </div>
        </form>
    </div>

    <!-- /#wrapper -->
    <script src="../JAVASCRIPT/classie.js"></script>
    <script src="../JAVASCRIPT/selectFx.js"></script>
    <script src="../JAVASCRIPT/matchphp/classie.js"></script>
    <script src="../JAVASCRIPT/matchphp/demo1.js"></script>
    <script src="../JAVASCRIPT/matchphp2/demo1.js"></script>

    <?php
    echo "<style type='text/css'>";
    $i=0;
    while($i<10){
        echo ".cs-skin-elastic .cs-options li.a$i span {background-image: url(../images/flag-france.jpg);}";
        $i++;
    }
    echo "</style>";
    ?>
    <script>
        //grafiacas de todas las listas
			(function() {
				[].slice.call( document.querySelectorAll( 'select.cs-select' ) ).forEach( function(el) {
					new SelectFx(el);
				} );
			})();
    </script>
    <!-- jQuery -->
    <script src="../JAVASCRIPT/jquery_administrador.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../JAVASCRIPT/bootstrap.min.js"></script>
    <script src="../JAVASCRIPT/svgcheckbx.js"></script>
    <!--DROPDOWN DE LOS -->
    <script src="../JAVASCRIPT/checkbox.js"></script>
    <script src="../JAVASCRIPT/checkbox2.js"></script>
    <script src="../JAVASCRIPT/checkbox3.js"></script>
</body>

</html>
