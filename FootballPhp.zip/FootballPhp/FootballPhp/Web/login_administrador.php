<!DOCTYPE html>

<html>
<head>
    <link rel="icon" 
      type="image/png" 
      href="../images/logito.jpg">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="../Estilos/login_administrador.css" type="text/css" media="all" />
    <title>Login ADMINISTRADOR</title>

    <style type="text/css">
        body {
            background-image: url("../images/estadio.jpg");
            background-attachment: fixed;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>
<body>

   <form action="../Web/logicphp/login_administrador.php" method="post" class="informacion">
        <div class="graficos">
            Ingrese Su Usuario:
            <br /><br />
            <input Type="Text" name="usuario" ID="usuario" MaxLength="40" />
            <br /><br />
            Ingrese Su password:
            <br /><br />
            <input Type="password" name="pass" ID="pass" MaxLength="40" />
            <br /><br />
            <input Type="Submit" class="button" value="Ingresar" />
        </div>
    </form>
</body>
</html>