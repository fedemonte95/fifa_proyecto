<!DOCTYPE html>
<html lang="en">
<head>
        <link rel="icon" 
      type="image/png" 
      href="../images/logito.jpg">
    <!-- IMPORTACION DE JQUERY -->
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>

    <meta charset="UTF-8">
    <title>Dashboard </title>
    <!-- ************************* LINKS DE BOOTSTRAP **************************************************************-->
    <!-- Para visual se mete en el lay out -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>



    <!-- Latest compiled JavaScript -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <!--  CSS DE LOS SELECTORES CREADOS POR MI  -->
    <link rel="stylesheet" href="../Estilos/css_dashboard.css"> 

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="JAVASCRIPT/dashboardMenu.js"></script>

    <script>
     
        function showTeams(str) {
            if (str.length == 0) {
                document.getElementById("showSelect").innerHTML = "NADA";
                return;
            } else {
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function () {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("showSelect").innerHTML = xmlhttp.responseText;
                    }
                };
                xmlhttp.open("GET", "getSelectTeam.php?q=" + str, true);
                xmlhttp.send();
            }
        }
    </script>
</head>
<body background="">
    <br />
    <br />
    
    <div id='cssmenu'>
        <ul>
            <li><a href='../index.php'><span>Home</span></a></li>
            <li><a href='#'><span>Company</span></a></li>
            <li class='last'><a href='#'><span>Contact</span></a></li>
        </ul>
    </div>
    <br>
    <br>
    <br>
    <div>
        <p> Matches played: played / total</p>
        <p> Stage  : stage..</p>
        <p> Group : group </p>
        <p> Quantity of games per tournament </p>
        <table class="Principal" style="width:50%; font-size:large;">
            <tr>
                <!--ROW DE HEADERS -->
                <th style="background-color:black; color:white;"> Goals per Match </th>
                <th> Average Cards Per Match</th>
                <th> Average shots Per Team </th>
                <th> Actual Playing Time </th>
            </tr>
            <tr>
                <!--ROW DE DATOS -->
                <td> 4 </td><!-- DATOS GOLES -->
                <td>
                    <!-- DATOS DE TARJETAS -->
                    <table clas="tarjetas"style="margin:auto; border:none; width:50%">
                        <tr>
                            <th style="background: red;"> Red </th>
                            <th style="background: yellow;"> Yellow </th>
                        </tr>
                        <tr>
                            <td> 10 </td>
                            <td> 45 </td>
                        </tr>
                    </table>
                </td>
                <td>50</td><!-- Datos de tiros por patidos -->
                <td> 45 min</td><!-- Actual playing time -->
            </tr>
        </table>
        <br />
        <select onchange="showTeams(this.value)">
            <option value="">Evento</option>
               <?php
               //parte del logeo de administrador
               $servername =  "localhost";
               $username   =  "root";
               $password   =  "root";
               $connection =  mysql_connect($servername, $username, $password);

               // ahora se checkea la conexion 
               if (!$connection){ die("Connection failed: " .$connection->connect_error);}
               $selectdb = mysql_select_db('proyecto2');
               //fin de checkear la coneccion
               $petition = "select idEvento, nombre from evento";
               $rs = mysql_query($petition);

               while($row = mysql_fetch_array($rs))
               { 
                   echo "<option value=\"".$row['idEvento']."\">".$row['nombre']."</option>\n  ";
               }
               mysql_close($connection);
               ?>
        </select>
        
        <span id="showSelect"> </span>
        </div>
</body>
</html>
