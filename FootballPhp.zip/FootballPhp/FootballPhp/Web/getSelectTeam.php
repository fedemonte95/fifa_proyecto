<!DOCTYPE html>
<html>
<head>
</head>
<body>
 <?php
         $q = intval($_GET['q']);
         $q = $_REQUEST["q"];
         $servername =  "localhost";
         $username   =  "root";
         $password   =  "root";
         $connection =  mysql_connect($servername, $username, $password);
         // ahora se checkea la conexion
         if (!$connection){
             die("Connection failed: " .$connection->connect_error);
         }
         $selectdb   = mysql_select_db('proyecto2');
         $sql        = "
            select equipo.nombre, equipo.idequipo from equipo, evento_has_equipo, evento
            where(
		     (evento.idEvento = evento_has_equipo.Evento_idEvento) and 
		        (evento_has_equipo.equipo_idequipo = equipo.idequipo) and 
		        (evento.idEvento = '".$q."')
		    ); ";
         $result     = mysql_query($sql);
         echo "<select>";
         echo "<option value=''>-Equipo-</option>";
         while( $row = mysql_fetch_array($result) ) {
             echo "<option value=\"".$row['idequipo']."\">".$row['nombre']."</option>\n  ";
         }
         echo"</select>";
         mysql_close($con);
?>
</body>
</html>
