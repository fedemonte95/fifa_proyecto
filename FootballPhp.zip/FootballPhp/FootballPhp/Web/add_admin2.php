<!DOCTYPE html>
<html lang="en">

<head>   
 <link rel="icon" 
      type="image/png" 
      href="../images/logito.jpg">
    <?php $nombre = $_POST['equipos'];
          echo '<script>alert ("'. $nombre.'");</script>';
    ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="../Estilos/bootstrap.min.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="../Estilos/sb-admin.css" rel="stylesheet" type="text/css">

    <!-- Custom Fonts -->
    <link href="../Estilos/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--Estilos de la parte negra grafica-->
    <link rel="stylesheet" type="text/css" href="../Estilos/normalize_administrador.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/demo_administrador.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/cs-select_administrador.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/cs-skin-elastic_administrador.css" />
    <!--fin de la parte negra grafica-->
    <!--Parte grafica de ingresar texto-->
    <link rel="stylesheet" type="text/css" href="../Estilos/add_admin/cs-select.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/add_admin/cs-skin-boxes.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/add_admin/demo.css" />
    <link rel="stylesheet" type="text/css" href="../Estilos/add_admin/normalize.css" />
    <!--Fin de parte grafica texto-->
    <!--Posiciones de los jugadores tactica-->
    <link rel="stylesheet" type="text/css" href="../Estilos/add_admin/posiciones.css" />
    <!--Fin de la tactica-->
    <!--Este es el fondo de la pag-->
    
    <style type="text/css">
        body {
            background-image: url("../images/cancha.jpg");
            background-attachment: fixed;
            background-position: right;
            background-repeat: no-repeat;
            background-position-y:10px;
            background-position-x:100px;
            background-size: 100px 100px;
            background-size: 100% 100%;
        }
    </style>
    <!--fin del fondo-->
</head>

<body>
    <form action="../Web/logicphp/add_admin2php.php" method="POST">
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Admin</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> OPTIONS <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="../Web/add_administador.php"><i class="fa fa-fw fa-user"></i>New Admin</a>
                        </li>
                        <li>
                            <a href="../index.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="../Web/administrador.php"><i class="fa fa-fw fa-desktop">NEW CHAMPIONSHIP</i> </a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-arrows-v"></i> REGISTER <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="../Web/add_admin.php">ADD LINEUP</a>
                            </li>
                            <li>
                                <a href="../Web/stadium.php">ADD STADIUM</a>
                            </li>
                            <li>
                                <a href="../Web/add_admin_equipo.php">ADD TEAM</a>
                            </li>
                            <li>
                                <a href="../Web/add_players.php">ADD PLAYERS</a>
                            </li>
                            <li>
                                <a href="../Web/add_match.php">MATCH</a>
                            </li>
                            <li>
                                <a href="../Web/Update_player.php">UPDATES PLAYER</a>
                            </li>
                            <li>
                                <a href="../Web/Update_team.php">UPDATES TEAM</a>
                            </li>
                            <li>
                                <a href="../Web/Update_stadium.php">UPDATES STADIUM</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

            <div class="container-fluid">
                  <div class="container">
                        <div class="seleccion1">
                            <!--

                                OJO MAE ES AQUI
                                esta es la parte que uno seleciona una opcion y debe regresar el value

                            -->

                                <section>
                                    <select name="gender" class="cs-select cs-skin-boxes">
                                        <option value="#">PORTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='$i' data-class='a$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                                <!--
        
                                    HASTA AQUI!!!!!!!!!!!!!

                                -->
                            </div>
                            <div class="seleccion2">                        
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DEFENSA</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='b$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>

                            <div class="seleccion3">
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DEFENSA</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='c$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>                
                            <div class="seleccion4">            
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DEFENSA</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='d$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>  
                            <div class="seleccion5">  
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DEFENSA CENTRAL</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='e$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>  
                            <div class="seleccion6">  
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DELENTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='f$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>  
                            <div class="seleccion7">  
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DELENTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='g$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>  
                            <div class="seleccion8">  
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DELENTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='h$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>  
                            <div class="seleccion9">  
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DELENTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='i$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div> 
                            <div class="seleccion10">
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DELENTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='j$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>
                            <div class="seleccion11">                            
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>DELENTERO</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='k$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div> 
                            <div class="seleccion12">                            
                                <section>
                                    <select class="cs-select cs-skin-boxes">
                                        <option value="" disabled selected>CAPITAN</option>
                                        <?php
                                        $i=0;
                                        while($i<22){
                                            echo "<option value='jugador' data-class='l$i'>NOMBRE DEL JUGADOR$i</option>";
                                            $i++;
                                        }
                                        ?>
                                    </select>
                                </section>
                            </div>    
                            <div class="wrapper">
                                <section>
					                <h1 class="letra">SAVE</h1>
					                <input type="submit" value="SAVE" class="push_button">     
                                </section>
                            </div>
                        </div>
                  </div>
            </div>    
        </form>
    <!-- /#wrapper -->
    <script src="../JAVASCRIPT/classie.js"></script>
    <script src="../JAVASCRIPT/selectFx.js"></script>
    <script>
			(function() {
				[].slice.call( document.querySelectorAll( 'select.cs-select' ) ).forEach( function(el) {
				    new SelectFx(el);
				} );
			})();
    </script>
    
    <?php
    echo "<style type='text/css'>";
    $i=0;
    while($i<22){
        echo ".cs-skin-boxes .cs-options li.a$i {background-image: url(../images/cara.jpg); background-repeat: no-repeat;}";
        $i++;
    }
    echo "</style>";
    ?>
    <?php
    echo "<style type='text/css'>";
    $i=0;
    while($i<22){
        echo ".cs-skin-boxes .cs-options li.b$i {background-image: url(../images/cara2.jpg); background-repeat: no-repeat;}";
        $i++;
    }
    echo "</style>";
    ?>>
    <?php
    echo "<style type='text/css'>";
    $i=0;
    while($i<22){
        echo ".cs-skin-boxes .cs-options li.c$i {background-image: url(../images/cara2.jpg); background-repeat: no-repeat;}";
        $i++;
    }
    echo "</style>";
    ?>

    <!-- jQuery -->
    <script src="../JAVASCRIPT/jquery_administrador.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../JAVASCRIPT/bootstrap.min.js"></script>

</body>

</html>
