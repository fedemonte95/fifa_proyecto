<!DOCTYPE html>
<html lang="en" class="no-js" xmlns="http://www.w3.org/1999/xhtml">
<head >
        <link rel="icon" 
      type="image/png" 
      href="../images/logito.jpg">
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/> 
    <title>Estadisticas</title>
    <link rel="stylesheet" href="../Estilos/estadistica1.css"type="text/css"/>
    <link rel="stylesheet" href="../Estilos/estadistica2.css"type="text/css"/>
    <link rel="stylesheet" href="../Estilos/estadistica3.css"type="text/css"/>
    <style type="text/css">
    body{
        background-image: url("../images/estadio_nacional.jpg");
        background-attachment: fixed;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover;

     }
    </style>
    <script>

        function showTeams(str) {
            if (str.length == 0) {
                document.getElementById("showTeams").innerHTML = "";
                return;
            } else {
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function () {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("showTeams").innerHTML = xmlhttp.responseText;
                    }
                };
                xmlhttp.open("GET", "getTeamsEstadistica.php?q=" + str, true);
                xmlhttp.send();
            }
        }
    </script>
</head>
<body>
    
           <form>
               
           <div class='container'>
           <div class='component'>
               <select onchange="showTeams(this.value)">
                   <option value="">Event</option>
                    <?php
                    //parte del logeo de administrador
                    $servername =  "localhost";
                    $username   =  "root";
                    $password   =  "root";
                    $connection =  mysql_connect($servername, $username, $password);

                    // ahora se checkea la conexion 
                    if (!$connection){ die("Connection failed: " .$connection->connect_error);}
                    $selectdb = mysql_select_db('proyecto2');
                    //fin de checkear la coneccion
                    $petition = "select idEvento, nombre from evento";
                    $rs = mysql_query($petition);

                    while($row = mysql_fetch_array($rs))
                    { 
                        echo "<option value=\"".$row['idEvento']."\">".$row['nombre']."</option>\n  ";
                    }
                    mysql_close($connection);
                    ?>
               </select>
 <!-- -------------------------------------------------------------------------------------------------------------------------------- -->
               <table>
               <thead>
               <tr>
                    <th>Teams</th>
                    <th>MP   </th>
                    <th>W    </th>
                    <th>D    </th>
                    <th>L    </th>
                    <th>GF   </th>
                    <th>GA   </th>
                    <th>+/-  </th>
                    <th>GF   </th>
                    <th>FPP  </th>
                    <th>Pts  </th>
                </tr>
                </thead>

                <tbody id="showTeams">
                
                </tbody>

                </table>
               
           </div>
           </div>
		   </form>
        <!-- /container -->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-throttle-debounce/1.1/jquery.ba-throttle-debounce.min.js"></script>
		<script src="../JAVASCRIPT/estadisticas.js"></script>
</body>
</html>