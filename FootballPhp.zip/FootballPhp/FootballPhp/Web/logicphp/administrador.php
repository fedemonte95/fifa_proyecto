 <?php

//php para usar lenght
$servername =  "localhost";
$username   =  "root";
$password   =  "root";
$connection =  mysql_connect($servername, $username, $password);
// ahora se checkea la conexion 
if (!$connection){ die("Connection failed: " .$connection->connect_error);}
$selectdb = mysql_select_db('proyecto2');

//variables
$name = $_POST['name'];
$canfe = $_POST['confe'];
$team = $_POST['team'];
$event = $_POST['even'];
$country = $_POST['country'];
$day = $_POST['day'];
$month = $_POST['month'];
$year = $_POST['year'];
$cantidad = count($team);

$fecha = "$year/$month/$day";

//fin variables
$sql="call insert_evento('$name','$fecha', $cantidad,$event);";
$createtable=mysql_query ($sql, $connection);
    
if(!$createtable){
    echo "ERROR1";
}

$sqlquery2="select idEvento, nombre from evento where nombre = '$name';";
$resul = mysql_query($sqlquery2, $connection);

while($rs = mysql_fetch_array($resul)){
    $idevent = $rs['idEvento'];
    echo "$idevent";
}
if(!$resul){
    echo "ERROR2";
}

$i=0;
while($i<cantidad){
    $guardar = $team[$i];
    $sql1="call Insert_Evento_has_Equipo($idevent, $guardar);";
    $createtable1=mysql_query ($sql1, $connection);
    if(!$createtable1){
        echo "ERROR3";
    }
}

$sql2="call Insert_Evento_has_Confederaciones($idevent,$canfe);";
$createtable2=mysql_query ($sql2, $connection);
if(!$createtable2){
    echo "ERROR4";
}else{
    header('Location: ../administrador.php');
}

?>