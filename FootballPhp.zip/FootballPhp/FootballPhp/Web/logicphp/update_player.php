<?php
header('Location: ../Update_player1.php');
?>