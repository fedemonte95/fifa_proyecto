<?php
    
    $team1 = $_POST["team1"];
    $time1 = $_POST["time1"];
    $player1 = $_POST["player1"];
    $action1 = $_POST["action1"];
    $team2 = $_POST["team2"];
    $time2 = $_POST["time2"];
    $player2 = $_POST["player2"];
    $action2 = $_POST["action2"];

    echo "$team1";
    echo "$team2";
    echo "$time1";
    echo "$time2";
    echo "$action1";
    echo "$action2";
    echo "$player1";
    echo "$player2";
    



?>
