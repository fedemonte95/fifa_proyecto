<?php
    $nombre = $_POST['gender'];
    echo '<script>alert ("'. $nombre.'");</script>';
    header('Location: ../add_admin.php');
?>
