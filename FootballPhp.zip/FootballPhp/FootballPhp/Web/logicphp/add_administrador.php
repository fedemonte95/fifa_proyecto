<?php
$servername =  "localhost";
$username   =  "root";
$password   =  "root";
$connection =  mysql_connect($servername, $username, $password);
// ahora se checkea la conexion
if (!$connection){ die("Connection failed: " .$connection->connect_error);}
$selectdb = mysql_select_db('proyecto2');
//variables
$name1[] = $_REQUEST['stadiums'];
$name2[] = $_REQUEST['team'];
$name3 = $_POST['event'];
$name4 = $_POST['country'];
$name5 = $_POST['day'];
$name6 = $_POST['month'];
$name7 = $_POST['year'];
//fin variables
echo "1$name1[0]<br/>2$name2[1]<br/>3$name3<br/>4$name4<br/>5$name5<br/>6$name6<br/>7$name7<br/>";
//$sqlquery="call insert_action()";
$createtable=mysql_query ($sqlquery, $connection);
if(!$createtable){
    echo "hola";
}
