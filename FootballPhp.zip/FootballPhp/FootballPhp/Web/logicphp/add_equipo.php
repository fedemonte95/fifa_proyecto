<?php
//php para usar lenght
$servername =  "localhost";
$username   =  "root";
$password   =  "root";
$connection =  mysql_connect($servername, $username, $password);
// ahora se checkea la conexion
if (!$connection){ die("Connection failed: " .$connection->connect_error);}
$selectdb = mysql_select_db('proyecto2');

//variables
$fill= $_POST['bandera'];
$bandera="../IMAGENES_DE_LA_BASE_DE_DATOS/$fill";
$coach = $_POST['coach'];
$name = $_POST['name'];
$country = $_POST['country'];
$confederation = $_POST['confederation'];
//fin variables
echo "<p>$bandera</p>";
echo "<p>$country</p>";
echo "<p>$name</p>";
echo "<p>$coach</p>";
echo "<p>$confederation</p>";
//$sqlquery="call insert_equipo('Seleccion', '../IMAGENES_DE_LA_BASE_DE_DATOS/costarica.jpg', 'PINTO', 1,6);";
$sqlquery="call insert_equipo('$name', '$bandera', '$coach', '$confederation', '$country' );";
$resul = mysql_query($sqlquery, $connection);

//ERROR
if(!$resul){
    echo "ERROR";
}else{
    header('Location: ../stadium.php');
}
?>