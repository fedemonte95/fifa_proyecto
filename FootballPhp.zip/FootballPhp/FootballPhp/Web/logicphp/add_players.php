<?php
//php para usar lenght
$connection =  mysql_connect("localhost", "root", "root");
// ahora se checkea la conexion
if (!$connection){ die("Connection failed: " .$connection->connect_error);}
$selectdb = mysql_select_db('proyecto2');
//variables
$name = $_POST['name'];
$lastname = $_POST['lastname'];
$id = $_POST['id'];
$country = $_POST['country'];
$shirtnum = $_POST['shirtnum'];
$team = $_POST['team'];
$position = $_POST['position'];
$fil = $_POST['file'];

$file = "../IMAGENES_DE_LA_BASE_DE_DATOS/$fil";

echo $name;
echo "<br/>";
echo $lastname;
echo "<br/>";
echo $id;
echo "<br/>";
echo $country;
echo "<br/>";
echo $shirtnum;
echo "<br/>";
echo $team;
echo "<br/>";
echo $position;
echo "<br/>";
echo $file;

//fin variables
//(pPais int, pPosicion int )

$sqlquery="call insert_jugador($shirtnum,'$name','$lastname','$id','$file',$team,$country,$position);";
$resul = mysql_query($sqlquery, $connection);
//ERROR
if(!$resul){
    echo "ERROR";
}else{
    header('Location: ../add_players.php');
}
?>