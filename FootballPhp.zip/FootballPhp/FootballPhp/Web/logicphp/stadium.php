<?php
//php para usar lenght
$servername =  "localhost";
$username   =  "root";
$password   =  "root";
$connection =  mysql_connect($servername, $username, $password);
// ahora se checkea la conexion
if (!$connection){ die("Connection failed: " .$connection->connect_error);}
$selectdb = mysql_select_db('proyecto2');

//variables
$country = $_POST['country'];
$stadium= $_POST['stadium'];
$capacity = $_POST['capacity'];
//fin variables

$sqlquery="call insert_estadio('$stadium',$country,$capacity);";
$resul = mysql_query($sqlquery, $connection);

//ERROR
if(!$resul){
    echo "ERROR";
}else{
    header('Location: ../stadium.php');
}
?>