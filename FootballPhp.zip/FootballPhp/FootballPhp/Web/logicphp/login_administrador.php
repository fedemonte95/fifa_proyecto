<?php 

//parte del logeo de administrador
$connection =  mysql_connect("localhost", "root", "root");

// ahora se checkea la conexion 
if (!$connection){ die("Connection failed: " .$connection->connect_error);}
$selectdb = mysql_select_db('proyecto2');
//fin de checkear la coneccion
//variables
$usuario = $_POST["usuario"];
$pass = $_POST["pass"];
//fin variables

//Solo llama a username para que sea mas eficiete
$sql="select username from administrador;";
$result = mysql_query($sql, $connection);
//Parte de desencriptar 

$sqlquery2="select proyecto2.buscar_pass('$pass');";
$result1 = mysql_query($sqlquery2, $connection);
$re = mysql_fetch_array($result1);
echo $re[0]+"<br/>";
//Fin de desenciptar

$bool = FALSE ;
while($record = mysql_fetch_array($result)){       //esta parte cambiar para desencriptar

    $save = $record['username'];
    if(strcmp($save,$usuario) == 0 and $re[0] == 1){
        $bool = TRUE;
    }
}

if($bool == FALSE){
    header('Location: ../login_administrador.php');
}else{
    header('Location: ../administrador.php');
}
$createtable=mysql_query ($sql, $connection);
if(!$createtable){
    echo "no funciona";
}

?>
