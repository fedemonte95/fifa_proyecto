<!DOCTYPE html>

<html>
<head>
    <link rel="icon" 
      type="image/png" 
      href="../images/logito.jpg">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="../Estilos/home.css" type="text/css" media="all" />
    <title>FOOTBALL</title>
    <!--Inicio Script-->
    <script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="JAVASCRIPT/jquery.slides.min.js"></script>
    
    <script>
            $(function(){
                $(".imagenes_slides").slidesjs({

                });
            });
    </script>
    <!--Fin Script-->
</head>
<body>
    <div class="image">
        <img SRC="../images/logo.jpg" width="500" height="130"/>
    </div>

    <!-- Inicio Header -->
    <div id="header"><div class="shell"></div></div>
    <!-- fin Header -->
    <!-- Navegacion -->
    <div id="navigation">
        <div class="image1">
        <a href="https://www.facebook.com/FIFO-719212354851557/?fref=ts"><img SRC="../images/logoFacebook.jpg" width="50" height="40"/></a>
    </div>
        <div class="shell">
            <div class="cl">&nbsp;</div>
            <ul>
                <li><a href="Web/login_administrador.php">ADMINISTRATOR</a></li>
            </ul>
            <div class="cl">&nbsp;</div>
        </div>
    </div>
    <!-- Fin Navegacion -->
    <!-- Heading -->
    <div id="heading">
        <div class="shell">
            <div id="heading-cnt">
                <!-- Sub nav -->
                <div id="side-nav">
                    <ul>
                        <li class="active">
                            <div class="link"><a href="./Web/index.php">home</a></div>
                        </li>
                        <li>
                            <div class="link"><a href="../Web/estadisticas.php">POSITIONS TABLE</a></div>
                        </li>
                        <li>
                            <div class="link"><a href="#">RESULTS</a></div>
                        </li>
                        <li>
                            <div class="link"><a href="./Web/Dashboard.php">DASHBOARD</a></div>
                        </li>
                    </ul>
                </div>
                <!-- Fin Sub nav -->
                <!-- Inicio SLIDE -->
                <div class="slides">
                    <div class="imagenes_slides">
                        <img src="images\navas.jpg" alt="">
                        <img src="images\messi.jpg" alt="">
                    </div>
                </div>
                <!-- Fin SLIDE -->
            </div>
        </div>
    </div>
    
<!--esto solo es un ejemplo de como conectarse a la base de datos de my sql*/-->
<?php

$servername = 'localhost';
$username = 'root';
$password = "root";

// Create connection
$db = new mysqli($servername, $username, $password);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
} 
echo "Connected successfully (".$db->host_info.")";
?>
<!--Fin de llamar a la base de datos-->

</body>

</html>